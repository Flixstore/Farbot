from os import path, getenv

class Config:
    API_ID = int(getenv('API_ID','28101262'))
    API_HASH = getenv('API_HASH','95d622dfced11833efdc7480d8d60d6f')
    BOT_TOKEN = getenv('BOT_TOKEN','6663686422:AAGv694q-7qsBnybU81YDE4zWDR-qpb0P7s')

config = Config()
