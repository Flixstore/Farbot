from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton

_start = """<b><a href="tg://resolve?domain=DONC6BOT">•   𝐀𝐥𝐢𝐜𝐞   • [ 🥀 ]</a>          <code>ϟ {hora}</code>

ϟ 𝐒𝐭𝐚𝐭𝐞         <code> {estado}</code>
ϟ 𝐈𝐃                  <code> {user_id} </code> 
ϟ 𝐀𝐥𝐢𝐚𝐬                <code>CCBlAbot</code>
ϟ 𝐕𝐞𝐫𝐬𝐢𝐨𝐧          <code>1.2</code>
━━━━━━━━━━━━━🤍🕊
ϟ 𝐃𝐚𝐭𝐞            <code>{tiempo}</code> 
『𝘋𝘦𝘝 ↯』: <b><a href="tg://resolve?domain=Was_FaReS">𝑭𝒂𝑹𝒆𝑺</a></b>
ϟ 𝐆𝐑: <b><a href="tg://resolve?domain=CRKSOO_CC7"> ͟͞S ✘</a></b>
</b>
"""


_cmd = """<b><b><a href="tg://resolve?domain=Was_FaReS">𝑳𝒊𝒔𝒕 𝑪𝒐𝒎𝒂𝒏𝒅 ☁</a></b>

ϟ 𝑮𝒂𝒕𝒆𝒘𝒂𝒚                    <code>8</code>
ϟ 𝑺𝒕𝒂𝒕𝒖𝒔                           <code>ON ✅</code>
━━━━━━━━━🤍🕊
ϟ𝑻𝒐𝒐𝒍𝒔                              <code>14</code>
ϟ 𝑺𝒕𝒂𝒕𝒖𝒔                          <code>ON ✅</code></b>
━━━━━━━━━🤍🕊
</b>
"""

_cmdbotons = InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton( 
                            "𝑮𝒂𝒕𝒆𝒔",
                            callback_data="gates"
                        ),
                        InlineKeyboardButton(
                            "𝑻𝒐𝒐𝒍𝒔",
                            callback_data="tools"
                        ),
                    ],
                    [
                        InlineKeyboardButton( 
                            "  𝑪𝒉𝒂𝒏𝒏𝒆𝒍   ",
                            url="https://t.me/CRKSOO_CC"),
                        InlineKeyboardButton( 
                            "『𝘋𝘦𝘝 ↯』",
                            url="https://t.me/Was_FaReS"),
                        InlineKeyboardButton( 
                            "  𝑮𝒓𝒖𝒐𝒑  ️",
                            url="https://t.me/CRKSOO_CC7"
                        ),
                    ],
                ]
            )

_Call_Gateways = """<b> <b><a href="tg://resolve?domain=Was_FaReS"> 𝑮𝒂𝒕𝒆𝒔 | 𝑮𝒂𝒕𝒆𝒘𝒂𝒚 🌑</a></b>

ϟ Chill | 𝘚𝘵𝘳𝘪𝘱𝘦 𝘊𝘩𝘢𝘳𝘨𝘦 <code>[𝘍𝘳𝘦𝘦🌩]</code>
ϟ Usar <code>/str card</code> On [ ✅ ]
━━━━━━━━━
ϟ Xilisio | 𝘚𝘵𝘳𝘪𝘱𝘦 𝘈𝘶𝘵𝘩 <code>[𝘍𝘳𝘦𝘦🌩]</code>
ϟ Usar <code>/xi card</code> On [ ✅ ]
━━━━━━━━━
ϟ Mass | 𝘚𝘵𝘳𝘪𝘱𝘦 𝘈𝘶𝘵𝘩 <code>[𝘗𝘳𝘦𝘮𝘪𝘶𝘮 🕊]</code>
ϟ Usar <code>/mass cards</code> On [ ✅ ]
━━━━━━━━━
ϟ Alga | 𝘚𝘵𝘳𝘪𝘱𝘦 𝘈𝘶𝘵𝘩 <code>[𝘗𝘳𝘦𝘮𝘪𝘶𝘮 🕊]</code>
ϟ Usar <code>/cr card</code> On [ ✅ ]
━━━━━━━━━
ϟ Yupi | 𝘚𝘵𝘳𝘪𝘱𝘦 𝘈𝘶𝘵𝘩 <code>[𝘗𝘳𝘦𝘮𝘪𝘶𝘮 🕊]</code>
ϟ Usar <code>/yu card</code> OFF [ x ]
━━━━━━━━━
ϟ Abigail | 𝘚𝘵𝘳𝘪𝘱𝘦 𝘊𝘩𝘢𝘳𝘨𝘦 <code>[𝘗𝘳𝘦𝘮𝘪𝘶𝘮 🕊]</code>
ϟ Usar <code>/br card</code> On [ ✅ ]
━━━━━━━━━
ϟ AsteKa | 𝘚𝘵𝘳𝘪𝘱𝘦 𝘊𝘩𝘢𝘳𝘨𝘦 <code>[𝘗𝘳𝘦𝘮𝘪𝘶𝘮 🕊]</code>
ϟ Usar <code>/az card</code> On [ ✅ ]
━━━━━━━━━
</b>"""

_Call_Tools = """<b><b> <b><a href="tg://resolve?domain=CRKSOO_CC">𝑯𝒆𝒓𝒓𝒂𝒎𝒊𝒆𝒏𝒕𝒂𝒔 | 𝑻𝒐𝒐𝒍𝒔 🌑</a></b>

ϟ Bin - <code>𝘍𝘳𝘦𝘦🌩</code>
ϟ Usar <code>/bin 456789</code>
━━━━━━━━━
ϟ Gen Ccs - <code>𝘍𝘳𝘦𝘦🌩</code>
ϟ Usar <code>/gen 456789|rnd|rdn|rdn</code> 
━━━━━━━━━
ϟ Gen Mass Ccs <code>𝘍𝘳𝘦𝘦🌩</code>
ϟ Usar <code>/genmass 456789|rnd|rnd|rnd</code>
━━━━━━━━━
ϟ Extra <code>𝘍𝘳𝘦𝘦🌩</code>
ϟ Usar <code>/extra 456789|rnd|rnd|rnd</code>
━━━━━━━━━
ϟ Pasty <code>𝘗𝘳𝘦𝘮𝘪𝘶𝘮 🕊</code>
ϟ Usar <code>/paster texto a subir a pasti</code>
━━━━━━━━━
ϟ Code img <code>𝘗𝘳𝘦𝘮𝘪𝘶𝘮 🕊</code>
ϟ Usar <code>/code texto a subir a Imagen code</code>
━━━━━━━━━
ϟ Ip - <code>𝘍𝘳𝘦𝘦🌩</code>
ϟ Usar <code>/ip 1.1.1.1</code>
━━━━━━━━━
ϟ Tu informacion - <code>𝘍𝘳𝘦𝘦🌩</code>
ϟ Usar <code>/info </code>
━━━━━━━━━
ϟ Info Del bot user - <code>𝘍𝘳𝘦𝘦🌩</code>
ϟ Usar <code>/me</code>
━━━━━━━━━
ϟ Rand - <code>𝘍𝘳𝘦𝘦🌩</code>
ϟ Usar <code>/rand </code> 
━━━━━━━━━
ϟ Rand Pais - <code>𝘗𝘳𝘦𝘮𝘪𝘶𝘮 🕊</code>
ϟ Usar <code>/rdn ar</code>
━━━━━━━━━
ϟ Zip code Postal - <code>𝘍𝘳𝘦𝘦🌩</code>
ϟ Usar <code>/zip 10020</code>
━━━━━━━━━
</b>"""

_Call_Gateways_buttons = InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton(
                    "𝑯𝒐𝒎𝒆 ",
                    callback_data="home"
                ),
                InlineKeyboardButton(
                    "𝑪𝒍𝒐𝒔𝒆",
                    callback_data="exit"
                ),
        ]
        ]
    )
