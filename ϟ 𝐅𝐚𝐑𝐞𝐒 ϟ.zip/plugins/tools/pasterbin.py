
import os
import re
import json
import aiohttp
import requests
from pyrogram import Client, filters

#Headers
headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.104 Safari/537.36",
    "content-type": "application/json",
}

#Pastebins
async def p_paste(message, extension=None):
    siteurl = "https://pasty.lus.pm/api/v1/pastes"
    data = {"content": message}
    try:
        response = requests.post(url=siteurl, data=json.dumps(data), headers=headers)
    except Exception as e:
        return {"error": str(e)}
    if response.ok:
        response = response.json()
        purl = (
            f"https://pasty.lus.pm/{response['id']}.{extension}"
            if extension
            else f"https://pasty.lus.pm/{response['id']}.txt"
        )
        return {
            "url": purl,
            "raw": f"https://pasty.lus.pm/{response['id']}/raw",
            "bin": "Pasty",
        }
    return {"error": "Unable to reach pasty.lus.pm"}


@Client.on_message(filters.command(["paster"]))
async def who_is(client, message):
    with open(file='plugins/usuarios/premium.txt',mode='r+',encoding='utf-8') as archivo:
        x = archivo.readlines()
        if str(message.from_user.id) + '\n' in x:
            tex_t = message.text
            if ' ' in message.text:
                message_s = message.text.split(" ", 1)[1]
            elif message.reply_to_message:
                message_s = message.reply_to_message.text
            else:
                await message.reply("<b>⎚ Usar <code>/paster 𝑻𝒆𝒙𝒕 𝑮𝒐𝒊𝒏𝒈 𝑼𝒑 𝑻𝒐 𝑷𝒂𝒔𝒕𝒆𝒓𝒃𝒊𝒏</code></b>")
            if not tex_t:
                if not message.reply_to_message:
                    await pablo.edit("<b>⎚ 𝑭𝒐𝒓𝒎𝒂𝒕𝒐 𝑰𝒏𝒗𝒂𝒍𝒊𝒅𝒐 𝑻𝒆𝒙𝒕 | 𝑪𝒐𝒄𝒖𝒎𝒆𝒏𝒕𝒐</b>")
                    return
                if not message.reply_to_message.text:
                    file = await message.reply_to_message.download()
                    m_list = open(file, "r").read()
                    message_s = m_list
                    os.remove(file)
                elif message.reply_to_message.text:
                    message_s = message.reply_to_message.text
            else:
                pablo = await message.reply_text("<b>⎚ `𝑪𝒍𝒊𝒎𝒃𝒊𝒏𝒈 𝑾𝒊𝒏𝒈 𝑷𝒂𝒔𝒕𝒆𝒓𝑩𝒊𝒏𝒅...`</b>")

            ext = "txt"
            x = await p_paste(message_s, ext)
            p_link = x["url"]
            p_raw = x["raw"]

            pasted = f"""<b>
━━━━━━━━━━━
♦ 𝐓𝐞𝐱𝐭 𝐎𝐧𝐥𝐢𝐧𝐞 🥀

♦ 𝑳𝒊𝒏𝒌 : 
♦  •[ [ 𝑷𝒓𝒆𝒔𝒊𝒐𝒏𝒆 ]({p_link}) ]
━
♦ 𝑳𝒊𝒏𝒌 𝑫𝒆 𝑹𝒂𝒘: 
♦ •[ [ 𝑷𝒓𝒆𝒔𝒊𝒐𝒏𝒆 𝑹𝒂𝒘]({p_raw}) ]

♦ 𝑺𝒕𝒂𝒕𝒖𝒔 : 𝑽𝒂𝒍𝒊𝒅 ✅
━━━━━━━━━━━
♦ 𝐁𝐨𝐭 𝐃𝐞𝐕: <b><a href="tg://resolve?domain=Was_FaReS">ϟ 𝐅𝐚𝐑𝐞𝐬 ϟ</a></b>
♦𝐆𝐑 : <b><a href="tg://resolve?domain=CRKSOO_CC7">⏤͟͞S ✘</a></b>
   </b> 
    """
            await pablo.edit(pasted, disable_web_page_preview=True)
        
        else:
            return await message.reply(f'<b>⎚ 𝑪𝒉𝒂𝒕 𝑵𝒐 𝑨𝒖𝒕𝒐𝒓𝒊𝒛𝒂𝒅𝒐 | 𝑶 𝑵𝒐 𝑬𝒓𝒆𝒔 𝑷𝒓𝒆𝒎𝒊𝒖𝒎.</b>')



