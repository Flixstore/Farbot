import requests 
from pyrogram import Client, filters
from pyrogram.types import Message
from pulpos.plantillas import _cmdbotons, _cmd

@Client.on_message(filters.command("zip"))
async def cmds(client, message):
    with open(file='plugins/usuarios/users.txt',mode='r+',encoding='utf-8') as archivo:
        x = archivo.readlines()
        if str(message.from_user.id) + '\n' in x:
            zipcode = message.text[len('/zip '):]
        if not zipcode:
            await message.reply("<b>⎚ Usar <code>/zip 10020</code></b>")
        spli = zipcode.split()
        zipo = spli[0]
        

        zip_api = requests.get(f'https://zip.getziptastic.com/v2/US/{zipo}').json()
        
    
        await message.reply(f"""
    <b>
━━━━🥀 [ϟ 𝒁𝒊𝒑 𝑪𝒐𝒅𝒆 ϟ] 🥀━━━━━
♦ 𝑪𝒐𝒖𝒏𝒕𝒓𝒚: <code>{zip_api['country']}</code>
♦ 𝑷𝒐𝒔𝒕𝒂𝒍 𝑪𝒐𝒅𝒆:<code> {zip_api['postal_code']}</code>
♦ 𝑪𝒊𝒕𝒚: <code>{zip_api['city']}</code>
♦ 𝑬𝒔𝒕𝒂𝒕𝒆: <code>{zip_api['state_short']}</code>
━━━━━━━━━━━━━━
♦𝐁𝐨𝐭 𝐃𝐞𝐕: <b><a href="tg://resolve?domain=Was_FaReS">ϟ 𝐅𝐚𝐑𝐞𝐬  ϟ</a></b>
♦ 𝐆𝐑 : <b><a href="tg://resolve?domain=CRKSOO_CC7">⏤͟͞S ✘</a></b>
    </b>""")