rom pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton


_0 = """<b>⎚ Chill | Stripe Charge 
Card: <code>{card}</code>
Progress: 🔴 1.0 sgd
</b>"""


_50 = """<b>⎚ Chill | Stripe Charge 
Card: <code>{card}</code>
Progress: 🟠 5.4 sgd
</b>"""

_100 = """<b>⎚ Chill | 𝘚𝘵𝘳𝘪𝘱𝘦 𝘊𝘩𝘢𝘳𝘨𝘦

ϟ 𝑪𝒂𝒓𝒅: <code>{card}</code>
ϟ 𝐒𝐭𝐚𝐭𝐮𝐬: <b>{status}</b>
ϟ 𝐑𝐞𝐬𝐩𝐨𝐧𝐬𝐞: <b>{result}</b>
ϟ 𝐆𝐚𝐭𝐞𝐰𝐚𝐲: <code>Chill</code>
━━━━━━━━━🤍🕊
ϟ 𝐏𝐫𝐨𝐱𝐲 : Live!✅
ϟ 𝘊𝘩𝘦𝘬𝘦𝘥 𝘣𝘺 : @{user}
ϟ 𝐓𝐢𝐦𝐞 𝐓𝐚𝐤𝐞𝐧: <b>{time}s</b>
━━━━━━━━━🤍🕊
『𝘋𝘦𝘝 ↯』 <b><a href="tg://resolve?domain=Was_FaReS">ϟ 𝐅𝐚𝐑𝐞𝐒 ϟ</a></b>
</b>"""
